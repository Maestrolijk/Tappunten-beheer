import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AfdelingenPage } from './afdelingen';

@NgModule({
  declarations: [
    AfdelingenPage,
  ],
  imports: [
    IonicPageModule.forChild(AfdelingenPage),
  ],
})
export class AfdelingenPageModule {}
