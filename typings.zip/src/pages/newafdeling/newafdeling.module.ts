import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewafdelingPage } from './newafdeling';

@NgModule({
  declarations: [
    NewafdelingPage,
  ],
  imports: [
    IonicPageModule.forChild(NewafdelingPage),
  ],
})
export class NewafdelingPageModule {}
