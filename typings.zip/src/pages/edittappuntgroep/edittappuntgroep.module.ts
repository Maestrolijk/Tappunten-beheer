import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EdittappuntgroepPage } from './edittappuntgroep';

@NgModule({
  declarations: [
    EdittappuntgroepPage,
  ],
  imports: [
    IonicPageModule.forChild(EdittappuntgroepPage),
  ],
})
export class EdittappuntgroepPageModule {}
