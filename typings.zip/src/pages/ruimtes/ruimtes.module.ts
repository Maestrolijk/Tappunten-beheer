import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RuimtesPage } from './ruimtes';

@NgModule({
  declarations: [
    RuimtesPage,
  ],
  imports: [
    IonicPageModule.forChild(RuimtesPage),
  ],
})
export class RuimtesPageModule {}
