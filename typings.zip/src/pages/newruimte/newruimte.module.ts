import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewruimtePage } from './newruimte';

@NgModule({
  declarations: [
    NewruimtePage,
  ],
  imports: [
    IonicPageModule.forChild(NewruimtePage),
  ],
})
export class NewruimtePageModule {}
