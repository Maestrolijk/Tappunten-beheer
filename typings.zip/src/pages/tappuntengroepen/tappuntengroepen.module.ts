import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TappuntengroepenPage } from './tappuntengroepen';

@NgModule({
  declarations: [
    TappuntengroepenPage,
  ],
  imports: [
    IonicPageModule.forChild(TappuntengroepenPage),
  ],
})
export class TappuntengroepenPageModule {}
