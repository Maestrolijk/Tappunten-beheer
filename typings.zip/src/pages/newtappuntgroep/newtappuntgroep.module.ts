import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewtappuntgroepPage } from './newtappuntgroep';

@NgModule({
  declarations: [
    NewtappuntgroepPage,
  ],
  imports: [
    IonicPageModule.forChild(NewtappuntgroepPage),
  ],
})
export class NewtappuntgroepPageModule {}
