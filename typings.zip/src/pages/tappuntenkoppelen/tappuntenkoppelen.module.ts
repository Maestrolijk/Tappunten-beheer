import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TappuntenkoppelenPage } from './tappuntenkoppelen';

@NgModule({
  declarations: [
    TappuntenkoppelenPage,
  ],
  imports: [
    IonicPageModule.forChild(TappuntenkoppelenPage),
  ],
})
export class TappuntenkoppelenPageModule {}
